import pygame, sys
pygame.init() # initialize the pygame system
size = (1000, 600) # window size is a 2-tuple measured in px
screen = pygame.display.set_mode(size)

# Load images
tile = pygame.image.load("tile.png")

# Initialize the clock
clock = pygame.time.Clock()
max_fps = 60 # maximum number of cycles (frames) per second

while True:
	clock.tick(max_fps) # limit the refresh rate to a max of 60 cycles per second
	
	# Quit when the user closes the window
	for event in pygame.event.get():
		if event.type == pygame.QUIT: sys.exit()

	screen.fill((255, 255, 255)) # RGB white color tuple

	screen.blit(tile, (200, 100)) # Draw the tile on the screen

	pygame.display.flip() # Display what was drawn this turn
