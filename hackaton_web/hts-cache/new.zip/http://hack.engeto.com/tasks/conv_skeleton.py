# -*- coding: utf-8 -*-
"""
Task: Conversion between bases

1) first, to create a function that takes in an integer and returns binary string
2) then create a function that takes in a binary string and returns an integer

you can test it with: decimal 22 = binary 10110

good explanation of theory is here: http://www.sallyx.org/sally/c/c02.php

Example:

22 / 2 = 11 rest add to str     '0'
11 / 2 =  5 rest add to str    '10'     
 5 / 2 =  2 rest add to str   '110'
 2 / 2 =  1 rest add to str  '0110'
 1 / 2 =  0 rest add to str '10110'
  
"""
'''
Example:
decimal * 2 + digit  
    
      0 * 2 + 1 = 1
      1 * 2 + 0 = 2
      2 * 2 + 1 = 5
      5 * 2 + 1 = 11
     11 * 2 + 0 = 22
'''
#-----------------------------------------------------


#-------------------skeleton--------------------
# conversion decimal to binary


# Read user input as integer and save it to variable called number
number = int(input("Enter decimal number you want convert to binary: "))
output = ""

while 
    print('number = ', number,'   output = ', output) # this will help you keep track content of variable  
    if 
        Add to output zero at the beginning of output
    else:
        
    number =      # division rounds down the result

print('Input number converted to binary is : ',output)        


# conversion binary to decimal
# Read user input as integer and save it to variable called number
binary = input("Enter binary number you want convert to decimal: ")
decimal = 

for     #you can iterate through binary string
    
    print('digit:', digit, 'decimal:', decimal)

print(binary, 'converted to decimal is:', decimal)

